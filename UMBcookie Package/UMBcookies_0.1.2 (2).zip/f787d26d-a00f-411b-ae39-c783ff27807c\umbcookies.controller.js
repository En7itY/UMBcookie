angular.module("umbraco").controller("UMBcookies",function ($scope) {
    //$scope.model.value = {};
    //For debbugig only
    var coockieMessage = $scope.model.value.message;
    var cookieDismissText = $scope.model.value.dismiss;
    var cookiePolicyText = $scope.model.value.policy;
    var cookieLink = $scope.model.value.link;
    var buttonBackgroundColor = $scope.model.value.buttonBackground;
    var buttonTextColor = $scope.model.value.buttonText;
    var PopupBackgroundColor = $scope.model.value.popupBackground;
    var PopupTextColor = $scope.model.value.popupText;
	var colorTest = $scope.model.value.color;


    var cookiePosition = $scope.model.value.position;
    var cookieLayout = $scope.model.value.layout;


    //debugger;
    });